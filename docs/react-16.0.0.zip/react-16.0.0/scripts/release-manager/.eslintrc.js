'use strict';

module.exports = {
  rules: {
    'no-shadow': 0,
  },
};
