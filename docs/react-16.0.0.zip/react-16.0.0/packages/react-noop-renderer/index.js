'use strict';

module.exports = require('./cjs/react-noop-renderer.development.js');
